(function() {
	console.log('start gulp template');
})();